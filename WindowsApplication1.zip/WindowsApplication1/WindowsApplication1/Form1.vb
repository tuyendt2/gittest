﻿Imports System.Text.RegularExpressions
Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
            Try
                Dim directory As String = FolderBrowserDialog1.SelectedPath
                Console.WriteLine(FolderBrowserDialog1.SelectedPath)
                For Each foundFile As String In My.Computer.FileSystem.GetFiles(directory,
                    Microsoft.VisualBasic.FileIO.SearchOption.SearchAllSubDirectories, "*.cpp")
                    Dim contentFile As String = IO.File.ReadAllText(foundFile)
                    '{(\s*\w*)ETG_TRACE_FATAL*\s*\(\s*\((.)*\)\s*;\s*ETG_TRACE_ERRMEM*\s*\(\s*\((.)*\)\s*;\s*}|{(\s*\w*)ETG_TRACE_ERRMEM*\s*\(\s*\((.)*\)\s*;\s*ETG_TRACE_FATAL*\s*\(\s*\((.)*\)\s*;\s*}
                    Dim regex As New Regex("{[^{]*(\s*\w*)ETG_TRACE_FATAL*\s*\(\s*\((.)*\)\s*;\s*[^}]*\s*ETG_TRACE_ERRMEM*\s*\(\s*\((.)*\)\s*;[^}]*}|{(\s*\w*)ETG_TRACE_ERRMEM*\s*\(\s*\((.)*\)\s*;\s*ETG_TRACE_FATAL*\s*\(\s*\((.)*\)\s*;\s*}")
                    Dim isMatch As Match = regex.Match(contentFile)
                    If isMatch.Success Then
                        Console.WriteLine(foundFile)
                    End If
                Next
                MessageBox.Show("Finished!")
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try

        End If
    End Sub
End Class


