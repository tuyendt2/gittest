#include "fgconfig.h"


#define PATH "C:/Users/GUT3HC/Desktop/FG config/FGconfig/DemoConfig - Copy.cfg" // dummy input path
#define PATH_OUTPUT "C:/Users/GUT3HC/Desktop/FG config/FGconfig/DemoConfig_Out.cfg" // dummy output path
using namespace std;
int main()
{
    // support comment
    // fix bug execute list
    // show error line
    vector<FGStartupInfo> mFGStartupInfoList = getFGConfig(PATH);
    if(mFGStartupInfoList.size() > 0){
        for(uint i = 0 ; i < mFGStartupInfoList.size(); i++){
            cout << "FG "<< i +1 << endl;
            mFGStartupInfoList[i].toString();
        }
        exportFile(mFGStartupInfoList,PATH_OUTPUT);
    }
}
