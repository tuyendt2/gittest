#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <regex>
using namespace std;

#define PATH "C:/Users/GUT3HC/Desktop/FG config/FGconfig/ParserSM/testMaxLengthFile.txt" //

int main(){
    ifstream file(PATH);
    if(!file){
        cout << "Invalid file !" << endl;
    }
    std::stringstream buffer;
    buffer << file.rdbuf();
    std::string str = buffer.str();
    file.close();

    try {
    std::regex fileRegex("([\\w\\d]+\\s*\\,\\s*)+");
     std::smatch m_smatch;
     cout << "start" << endl;
      //std::regex fileRegex("\\s*FG\\s*:\\s*\\[\\s*(\\{[\\w\\s\\/\\d]*Name\\s*:\\s*[^\\s,]*,\\s*(\\/\\/\\s*[^\\n]*)*\\s*State\\s*:\\s*[^\\s,]*,\\s*(\\/\\/\\s*[^\\n]*)*\\s*ExecuteList\\s*:\\s*\\[(\\s*[^\\s,\\]]*\\s*,\\s*)+\\],\\s*DependencyFGList\\s*:\\s*\\[(\\s*[\\S]*\\s*:\\s*\\{\\s*[^,]*,\\s*[\\w]*\\s*\\},?\\s*)+\\]\\s*\\}\\s*(,)?\\s*)+\\]\\s*");
      regex_search(str,m_smatch,fileRegex);
      cout << "search " << endl;
      if((unsigned int)m_smatch.length() == str.size() ){
        cout << "Valid file" << endl;
      }else{
        cout << "Invalid file!" << m_smatch.length() << endl;
      }
      cout << "finished " << endl;
    }catch (exception e){
        cout << "exception " <<endl;
        cout << e.what();
    }
    return 0;
}
