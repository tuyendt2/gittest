#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <regex>
#include <bits/stdc++.h>
#include "fgconfig.h"


#define PATH "C:/Users/GUT3HC/Desktop/parse config/DemoConfig - Copy.cfg" // dummy value

using namespace std;
int main()
{
    vector<FGStartupInfo> mFGStartupInfoList = getFGConfig(PATH);
    for(uint i = 0 ; i < mFGStartupInfoList.size(); i++){
        cout << "FG "<< i +1 << endl;
        mFGStartupInfoList[i].toString();
    }
}
