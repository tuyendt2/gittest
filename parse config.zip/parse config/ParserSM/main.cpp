#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <regex>

using namespace std;
#define PATH "C:/Users/GUT3HC/Desktop/parse config/DemoConfig.cfg"
enum SyncPointType : uint16_t {
    kFGActivated =0,
    kAllComponentRegistered,
    kAllComponentReachedFirstState,
    kFreeDefined
};
struct DependencyFG {
    DependencyFG(){};
    std::string FGname;
    SyncPointType type;
};
class FGStartupInfo{

public:
    FGStartupInfo(){};
    virtual         ~FGStartupInfo(){};
    std::string name;
    //Internal FG info
    std::string state;
    std::vector <std::string> exeName;
    bool bHasTriggeredActivate;
    //Sync Points related to FG
    bool bActivatedSync;
    bool bAllComponentOfFGRegisteredSync;
    bool bAllComponentOfFGReachedFirstStateSync;
    //FG dependencies
    std::vector <DependencyFG> listDependFG;

protected:

};
int main()
{
    string fileName  = PATH;
    ifstream file(fileName);
    if(!file){
        cout << "Invalid file !" << endl;
    }
    std::stringstream buffer;
    buffer << file.rdbuf();
    string str = buffer.str();


try {
  std::regex fGRegex("\\{[\\w\\s\\/\\d]*Name\\s*:\\s*[^\\s,]*,\\s*(\\/\\/\\s*[^\\n]*)*\\s*State\\s*:\\s*[^\\s,]*,\\s*(\\/\\/\\s*[^\\n]*)*\\s*ExecuteList\\s*:\\s*\\[\\/\\/ array(\\s*[^\\s,\\]]*,\\s*)+\\],\\s*DependencyFGList\\s*:\\s*\\[(\\s*[\\S]*\\s*:\\s*{\\s*[^,]*,\\s*[\\w]*\\s*},?\\s*)+\\]\\s*}");
  //std::regex re("\\w+");
  std::sregex_iterator next(str.begin(), str.end(), fGRegex);
  std::sregex_iterator words_end  = std::sregex_iterator();
  std::cout << __FUNCTION__ <<__LINE__ << "\n";
  while (next != words_end) {
    std::smatch match = *next;
    std::cout << match.str() << "\n";
    next++;
  }
} catch (std::regex_error& e) {
  // Syntax error in the regular expression
}

    /*
    std::cout << "hello " << endl;
std::vector <FGStartupInfo> databaseFG;
std::ifstream file(PATH);
string line;
string OldFGFound ="notFound";


while (getline(file,line)){
   // cout<<line<<endl;
    string fgTagName ="[FGname]:";
    string exeListTag="exelist:";
    string dependFGTag="dependFG:";
    std::size_t pos = line.find(fgTagName);      // position of "live" in str
    string currentFG;
    if(pos != std::string::npos){
        currentFG=line.substr(pos+fgTagName.size());
        cout<<"Found FG"<<currentFG<<endl;
    }
    if(currentFG != OldFGFound){
        FGStartupInfo infoFG;
        OldFGFound = currentFG;
        infoFG.name=currentFG;

        std::size_t posExe = line.find(exeListTag);
        if(posExe!= std::string::npos){
            string listOfExe = line.substr(posExe+exeListTag.size());
            cout<<"List of exe found: "<<listOfExe<<endl;
            string exeListRemaining = listOfExe;
            std::size_t posTemp = listOfExe.find(",");
            if(posTemp == std::string::npos){
                //Only 1 executable file found
                infoFG.exeName.push_back(listOfExe);
            }
             else{
                while(posTemp != std::string::npos){
                    string exeName = exeListRemaining.substr(0,posTemp);
                    infoFG.exeName.push_back(exeName);
                    cout<<"Found exe name:"<<exeName<<endl;
                    exeListRemaining = exeListRemaining.substr(posTemp+1);
                    posTemp = exeListRemaining.find(",");
                }

            }
            if(!exeListRemaining.empty()){
                infoFG.exeName.push_back(exeListRemaining);
                cout<<"Found exe name:"<<exeListRemaining<<endl;
            }

        }

       // Now push back to database
       databaseFG.push_back(infoFG);

        }
    }*/
   // cout << "Hello world!" << endl;
   cout << str << endl;
    return 0;
}
